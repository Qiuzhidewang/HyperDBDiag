"""Full-coverage ablation and preselected repeated-draw audit, no cherry-picking."""
from __future__ import annotations

import argparse
from collections import Counter
import csv
import json
from pathlib import Path
import numpy as np

from ecsa_fullcoverage_experiment import OUTPUT, ARMS, verify
from ecsa_isolation_experiment import write_json
from analyze_ecsa_conservative import metric, pool_audit
from hyperdbdiag_ablation import _revision_outcomes

METHODS = ['baseline','original_local','calibrated_local',*ARMS,'complete_local_fallback']
FAILURES = {'fallback_transport','fallback_invalid_response'}


def failure_gain_bounds(rows,left,right):
    """Respect a shared inference when bounding unknown failed executions."""
    low=high=shared=0
    for row in rows:
        failed={a:row[a+'_status'] in FAILURES for a in [left,right]}
        if all(failed.values()) and row[left+'_packet_sha256']==row[right+'_packet_sha256']:
            assert set(row[left])==set(row[right])
            shared+=1
            continue
        ranges={}
        for arm in [left,right]:
            correct=int(set(row[arm])==set(row['expected_labels']))
            ranges[arm]=(0,1) if failed[arm] else (correct,correct)
        low+=ranges[left][0]-ranges[right][1]
        high+=ranges[left][1]-ranges[right][0]
    return {'net_correct_range':[low,high],'shared_failed_pairs_with_zero_possible_pool_difference':shared}


def compare(rows,left,right,labels):
    outcomes=_revision_outcomes([r['expected_labels'] for r in rows],
                                [r[right] for r in rows],[r[left] for r in rows])
    folds=sorted({r['fold'] for r in rows})
    counts=[];gains=[]
    for fold in folds:
        group=[r for r in rows if r['fold']==fold]
        counts.append(len(group))
        gains.append(sum(int(set(r[left])==set(r['expected_labels']))-
                         int(set(r[right])==set(r['expected_labels'])) for r in group))
    counts=np.array(counts);gains=np.array(gains)
    indexes=np.random.default_rng(20260929).integers(0,len(folds),size=(20000,len(folds)))
    bootstrap=100*gains[indexes].sum(axis=1)/counts[indexes].sum(axis=1)
    return {**outcomes,'exact_gain_pp':100*float(gains.sum()/counts.sum()),
            'component_f1_gain_pp':100*(metric(rows,left,labels)['component_f1']-metric(rows,right,labels)['component_f1']),
            'fold_n':counts.tolist(),'fold_net_correct':gains.tolist(),
            'exploratory_fold_block_95ci_pp':np.quantile(bootstrap,[.025,.975]).tolist()}


def annotated_rows(prepared, decisions, draw='primary'):
    by_key={(r['case_id'],r['arm'],r['draw']):r for r in decisions}
    assert len(by_key)==len(decisions)
    rows=[]
    for original in prepared['rows']:
        if draw=='repeat' and not original['repeat_selected']:continue
        row=dict(original)
        for arm in ARMS if draw=='primary' else [ARMS[0],ARMS[2]]:
            result=by_key[(row['case_id'],arm,draw)]
            row[arm]=result['predicted_labels']
            row[arm+'_status']=result['status']
            row[arm+'_packet_sha256']=result['packet_sha256']
            assert any(set(row[arm])==set(candidate) for candidate in row['full_pool'])
        result=by_key[(row['case_id'],ARMS[2],draw)]
        row['complete_local_fallback']=result['local_fallback_prediction']
        assert any(set(row['complete_local_fallback'])==set(c) for c in row['conservative_pool'])
        rows.append(row)
    return rows


def analyze(output):
    protocol,prepared=verify(output)
    decisions=json.loads((output/'decisions.json').read_text())
    results={r['job_id']:r for r in decisions}
    assert len(decisions)==len(results)==len(prepared['jobs'])==2100
    assert set(results)=={j['job_id'] for j in prepared['jobs']}
    for job in prepared['jobs']:
        assert job['packet_sha256']==results[job['job_id']]['packet_sha256']
    rows=annotated_rows(prepared,decisions)
    assert len(rows)==660
    labels=prepared['labels']
    primary={m:metric(rows,m,labels) for m in METHODS}
    comparisons={f'{a}_vs_{b}':compare(rows,a,b,labels) for a,b in [
        ('calibrated_local','baseline'),('calibrated_local','original_local'),
        (ARMS[2],ARMS[0]),(ARMS[2],ARMS[1]),
        ('complete_local_fallback','calibrated_local'),
        ('complete_local_fallback',ARMS[0]),('complete_local_fallback',ARMS[2])
    ]}
    strata={
        'previously_reviewed_189':[r for r in rows if r['previously_reviewed']],
        'new_review_471':[r for r in rows if not r['previously_reviewed']],
        'filter_changed_pool':[r for r in rows if len(r['conservative_pool'])<len(r['full_pool'])],
        'filter_kept_full_pool':[r for r in rows if len(r['conservative_pool'])==len(r['full_pool'])],
        'single_root':[r for r in rows if len(r['expected_labels'])==1],
        'mixed_root':[r for r in rows if len(r['expected_labels'])>1],
    }
    stratum_results={name:{'n':len(group),'metrics':{m:metric(group,m,labels) for m in METHODS},
                    'filter_vs_full_llm':compare(group,ARMS[2],ARMS[0],labels),
                    'complete_vs_local':compare(group,'complete_local_fallback','calibrated_local',labels)}
                    for name,group in strata.items() if group}
    kept=[];removed=[];absent=[]
    for row in rows:
        truth=set(row['expected_labels'])
        if any(set(c)==truth for c in row['conservative_pool']):kept.append(row)
        elif any(set(c)==truth for c in row['full_pool']):removed.append(row)
        else:absent.append(row)
    filter_audit={name:{'n':len(group),'correct':{m:sum(set(r[m])==set(r['expected_labels']) for r in group) for m in METHODS}}
                  for name,group in [('gold_retained',kept),('gold_removed',removed),('gold_absent_upstream',absent)]}
    failure_cases=[r for r in rows if any(r[a+'_status'] in FAILURES for a in [ARMS[0],ARMS[2]])]
    no_failure=[r for r in rows if r not in failure_cases]
    failure_sensitivity={'paired_cases_with_execution_failure':len(failure_cases),
        'case_ids':[r['case_id'] for r in failure_cases],
        'filter_bounds_if_failed_executions_arbitrary':failure_gain_bounds(rows,ARMS[2],ARMS[0]),
        'paired_without_execution_failure_n':len(no_failure),
        'paired_without_execution_failure':compare(no_failure,ARMS[2],ARMS[0],labels),
        'note':'post-hoc sensitivity only; primary scores include every scheduled case with the frozen fallback; abstention is valid, not execution failure'}
    first=[r for r in rows if r['repeat_selected']]
    second=annotated_rows(prepared,decisions,'repeat')
    assert len(first)==len(second)==60
    assert [r['case_id'] for r in first]==[r['case_id'] for r in second]
    repeat_methods=['calibrated_local',ARMS[0],ARMS[2],'complete_local_fallback']
    repeats={'n':60,'selection':'10/fold, fixed before expansion outcomes, among cases whose pool is actually changed',
             'primary_draw':{m:metric(first,m,labels) for m in repeat_methods},
             'fresh_repeat_draw':{m:metric(second,m,labels) for m in repeat_methods},
             'primary_filter_vs_full':compare(first,ARMS[2],ARMS[0],labels),
             'repeat_filter_vs_full':compare(second,ARMS[2],ARMS[0],labels),
             'primary_complete_vs_local':compare(first,'complete_local_fallback','calibrated_local',labels),
             'repeat_complete_vs_local':compare(second,'complete_local_fallback','calibrated_local',labels),
             'prediction_agreement':{m:sum(set(a[m])==set(b[m]) for a,b in zip(first,second)) for m in repeat_methods[1:]},
             'note':'repeat is a sensitivity audit; it never replaces the primary draw and does not create 120 independent test cases'}
    usage={};statuses={}
    for arm in ARMS:
        records=[r for r in decisions if r['arm']==arm and r['draw']=='primary']
        assert len(records)==660
        statuses[arm]=dict(Counter(r['status'] for r in records))
        usage[arm]={key:sum(int(r['usage'].get(key,0) or 0) for r in records)
                    for key in ['input_tokens','cached_input_tokens','output_tokens','reasoning_output_tokens']}
        usage[arm]['analytical_cases']=sum(not r['model_called'] for r in records)
        usage[arm]['note']='logical per-arm sum, including shared recorded inferences; not actual newly consumed token totals'
    new_calls=[json.loads(line) for line in (output/'new_model_calls.jsonl').read_text().splitlines()]
    actual_usage={key:sum(int(r['usage'].get(key,0) or 0) for r in new_calls)
                  for key in ['input_tokens','cached_input_tokens','output_tokens','reasoning_output_tokens']}
    report={'status':'complete','primary_cases':660,'primary_all660':primary,'comparisons':comparisons,
            'strata':stratum_results,'pool_audit':pool_audit(rows),'filter_audit':filter_audit,'repeat_audit':repeats,
            'execution_failure_sensitivity':failure_sensitivity,
            'by_fold':{f['fold']:{m:metric([r for r in rows if r['fold']==f['fold']],m,labels) for m in METHODS}
                       for f in prepared['folds']},
            'primary_statuses':statuses,'logical_primary_usage':usage,'actual_new_usage':actual_usage,
            'run_completion':json.loads((output/'run_completion.json').read_text()),
            'protected_artifacts_unchanged':True,'independent_metric_counts_match_original_functions':True,
            'limitations':['same frozen v11 dataset with known scenarios and six acquisition-repeat folds',
                'expanded inference coverage; no newly collected independent evaluation dataset',
                'policy motivated by previous development analysis; unchanged during this expansion',
                'single primary draw per distinct input; fixed repeat audit covers only 60 changed-pool cases',
                'exact identical inputs share a decision; no artificial benefit from resampling unchanged pools',
                'fold-block intervals are exploratory with six resampling units; no unseen-scenario claim']}
    write_json(output/'analysis.json',report)
    with (output/'all660_case_audit.csv').open('w',newline='') as stream:
        fields=['case_id','fold','expected_labels',*METHODS,'previously_reviewed','repeat_selected',
                'full_pool_size','original_pool_size','conservative_pool_size',*[a+'_status' for a in ARMS]]
        writer=csv.DictWriter(stream,fieldnames=fields);writer.writeheader()
        for row in rows:
            record={k:row[k] for k in ['case_id','fold','previously_reviewed','repeat_selected']}
            record.update({m:'+'.join(sorted(row[m])) for m in ['expected_labels',*METHODS]})
            record.update({f+'_size':len(row[f]) for f in ['full_pool','original_pool','conservative_pool']})
            record.update({a+'_status':row[a+'_status'] for a in ARMS})
            writer.writerow(record)
    with (output/'repeat60_case_audit.csv').open('w',newline='') as stream:
        fields=['case_id','fold','expected_labels','calibrated_local']+[f'{m}_{draw}' for m in repeat_methods[1:] for draw in ['primary','repeat']]
        writer=csv.DictWriter(stream,fieldnames=fields);writer.writeheader()
        for one,two in zip(first,second):
            record={'case_id':one['case_id'],'fold':one['fold'],'expected_labels':'+'.join(sorted(one['expected_labels'])),
                    'calibrated_local':'+'.join(sorted(one['calibrated_local']))}
            record.update({f'{m}_{draw}':'+'.join(sorted(row[m])) for m in repeat_methods[1:]
                           for draw,row in [('primary',one),('repeat',two)]})
            writer.writerow(record)
    return report


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,default=OUTPUT)
    args=parser.parse_args();print(json.dumps(analyze(args.output),ensure_ascii=False,indent=2))
