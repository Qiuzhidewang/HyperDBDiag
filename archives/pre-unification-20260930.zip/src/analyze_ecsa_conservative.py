"""Audit every frozen cohort; no best-case selection or model-driven retuning."""
from __future__ import annotations
import argparse
from collections import Counter
import csv
import json
from pathlib import Path
import numpy as np

from ecsa_conservative_experiment import OUTPUT, ARMS, COHORTS, verify
from ecsa_isolation_experiment import write_json, metric as historical_metric
from hyperdbdiag_ablation import _revision_outcomes


def metric(rows, field, labels):
    pairs=[(set(r['expected_labels']),set(r[field])) for r in rows]
    tp=sum(len(t&p) for t,p in pairs);fp=sum(len(p-t) for t,p in pairs);fn=sum(len(t-p) for t,p in pairs)
    correct=sum(t==p for t,p in pairs)
    result={'n':len(rows),'correct':correct,'exact':correct/len(rows),
            'component_f1':2*tp/(2*tp+fp+fn),'tp':tp,'fp':fp,'fn':fn}
    other=historical_metric(rows,field,labels)
    for k in ['exact','component_f1']: assert abs(result[k]-other[k])<1e-12
    return result


def pool_audit(rows):
    result={}
    for field in ['full_pool','original_pool','conservative_pool']:
        result[field]={'mean_width':float(np.mean([len(r[field]) for r in rows])),
                       'gold_retained':sum(any(set(c)==set(r['expected_labels']) for c in r[field]) for r in rows),
                       'width_counts':dict(Counter(len(r[field]) for r in rows))}
    full=result['full_pool']['gold_retained']
    for v in result.values():v['conditional_gold_retention']=v['gold_retained']/full if full else None
    return result


def compare(rows,left,right,labels):
    result=_revision_outcomes([r['expected_labels'] for r in rows],[r[right] for r in rows],[r[left] for r in rows])
    folds=sorted({r['fold'] for r in rows})
    gains=[metric([r for r in rows if r['fold']==f],left,labels)['exact']-
           metric([r for r in rows if r['fold']==f],right,labels)['exact'] for f in folds]
    rng=np.random.default_rng(20260929)
    boot=np.mean(rng.choice(gains,size=(20000,len(gains)),replace=True),axis=1)
    result.update(exact_gain_pp=100*(metric(rows,left,labels)['exact']-metric(rows,right,labels)['exact']),
                  fold_gain_pp=[100*v for v in gains],
                  exploratory_six_fold_bootstrap_95ci_pp=(100*np.quantile(boot,[.025,.975])).tolist())
    return result


def analyze(output):
    protocol,prepared=verify(output)
    labels=prepared['labels'];rows=[dict(r) for r in prepared['rows']]
    local_methods=['baseline','original_local','calibrated_local']
    report={'status':'calibration_and_local_complete_llm_pending',
            'all_660_local':{m:metric(rows,m,labels) for m in local_methods},
            'all_660_pool_audit':pool_audit(rows),
            'calibration_by_fold':{f['fold']:f['calibration'] for f in prepared['folds']},
            'cohort_sizes':{c:sum(c in r['cohorts'] for r in rows) for c in COHORTS},
            'cohort_overlap':{f'{a}__{b}':sum(a in r['cohorts'] and b in r['cohorts'] for r in rows)
                              for i,a in enumerate(COHORTS) for b in COHORTS[i+1:]},
            'unique_scheduled_cases':prepared['unique_scheduled_cases'],
            'historical_changed_cases_covered':prepared['history_changed_cases_covered'],
            'all_660_local_changes':compare(rows,'calibrated_local','original_local',labels),
            'cohorts':{},'protected_artifacts_unchanged':True,
            'limitations':['same existing v11 dataset; revised policy motivated by previous observed failures',
                           'fresh_random is a new preselected inference cohort, not a new independent dataset',
                           'only training OOF data calibrate the two scalar decisions; no outer-label threshold selection',
                           'single model draw per distinct prompt/input, exact duplicates share the same recorded decision',
                           'six acquisition-repeat folds with known scenarios; bootstrap intervals are exploratory',
                           'historical sample cohort is reconstructed, but the prompt and calibration gate differ from the old published run']}
    path=output/'decisions.json'
    results={}
    if path.exists():
        decisions=json.loads(path.read_text());results={r['job_id']:r for r in decisions}
        assert len(results)==len(decisions)==len(prepared['jobs'])
        for job in prepared['jobs']:
            assert results[job['job_id']]['packet_sha256']==job['packet_sha256']
        for r in rows:
            for arm in ARMS:
                decision=results.get(f"{r['case_id']}:{arm}")
                r[arm]=decision['predicted_labels'] if decision else r['baseline']
            decision=results.get(f"{r['case_id']}:{ARMS[2]}")
            r['conservative_local_fallback']=(decision['predicted_labels'] if decision and decision['status']=='accepted_selection'
                                              else r['calibrated_local'])
        report['status']='complete'
        report['run_completion']=json.loads((output/'run_completion.json').read_text())
    methods=local_methods+(list(ARMS)+['conservative_local_fallback'] if results else [])
    for cohort in COHORTS:
        chosen=[r for r in rows if cohort in r['cohorts']]
        entry={'metrics':{m:metric(chosen,m,labels) for m in methods},'pool_audit':pool_audit(chosen)}
        if results:
            entry['comparisons']={f'{left}_vs_{right}':compare(chosen,left,right,labels) for left,right in [
                (ARMS[2],ARMS[0]),(ARMS[2],ARMS[1]),(ARMS[2],'calibrated_local'),
                ('conservative_local_fallback','calibrated_local'),('conservative_local_fallback',ARMS[0])
            ]}
            entry['by_fold']={f:{m:metric([r for r in chosen if r['fold']==f],m,labels) for m in methods}
                              for f in sorted({r['fold'] for r in chosen})}
            entry['logical_statuses']={a:dict(Counter(results[f"{r['case_id']}:{a}"]['status'] for r in chosen)) for a in ARMS}
            entry['logical_usage']={a:{key:sum(int(results[f"{r['case_id']}:{a}"]['usage'].get(key,0) or 0) for r in chosen)
                                     for key in ['input_tokens','output_tokens','reasoning_output_tokens']} for a in ARMS}
            integrated=[]
            for r in rows:
                item=dict(r)
                item['integrated_conservative']=r['conservative_local_fallback'] if cohort in r['cohorts'] else r['calibrated_local']
                item['budgeted_full_llm']=r[ARMS[0]] if cohort in r['cohorts'] else r['baseline']
                integrated.append(item)
            entry['all_660_flow_same_fixed_72_call_schedule']={m:metric(integrated,m,labels)
                            for m in ['baseline','calibrated_local','budgeted_full_llm','integrated_conservative']}
            kept=[r for r in chosen if any(set(c)==set(r['expected_labels']) for c in r['conservative_pool'])]
            lost=[r for r in chosen if any(set(c)==set(r['expected_labels']) for c in r['full_pool']) and r not in kept]
            entry['conservative_filter_audit']={name:{'n':len(group),'correct':{
                m:sum(set(r[m])==set(r['expected_labels']) for r in group) for m in ARMS}}
                for name,group in [('gold_retained',kept),('gold_removed',lost)]}
        report['cohorts'][cohort]=entry
    name='analysis.json' if results else 'deterministic_analysis.json'
    write_json(output/name,report)
    if results:
        fields=['case_id','fold','cohorts','expected_labels',*methods,'full_pool_width','old_pool_width','new_pool_width']
        with (output/'paired_case_audit.csv').open('w',newline='') as stream:
            writer=csv.DictWriter(stream,fieldnames=fields);writer.writeheader()
            for r in rows:
                if not r['cohorts']:continue
                line={k:r[k] for k in ['case_id','fold']};line['cohorts']='|'.join(r['cohorts'])
                line.update({m:'+'.join(sorted(r[m])) for m in ['expected_labels',*methods]})
                line.update(full_pool_width=len(r['full_pool']),old_pool_width=len(r['original_pool']),new_pool_width=len(r['conservative_pool']))
                writer.writerow(line)
    return report


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path,default=OUTPUT);args=p.parse_args()
    print(json.dumps(analyze(args.output),ensure_ascii=False,indent=2))
