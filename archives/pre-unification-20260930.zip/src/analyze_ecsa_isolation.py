"""Analyze the frozen matched ECSA run without changing any decisions."""
from __future__ import annotations
import argparse
from collections import Counter
import csv
import json
from pathlib import Path
import numpy as np
from ecsa_isolation_experiment import ARMS, digest, metric, file_digest, write_json
from hyperdbdiag_ablation import _revision_outcomes, _binomial_greater_p_value


def analyze(output: Path):
    prepared = json.loads((output/'prepared.json').read_text())
    protocol = json.loads((output/'protocol.json').read_text())
    assert digest(protocol) == prepared['protocol_sha256']
    decisions = [json.loads(line) for line in (output/'llm_decisions.jsonl').read_text().splitlines()]
    results = {r['job_id']: r for r in decisions}
    assert len(results) == len(decisions) == len(prepared['jobs']), 'wait for all preregistered jobs'
    for job in prepared['jobs']:
        assert digest(job['packet']) == job['packet_sha256'] == results[job['job_id']]['packet_sha256']
    for path, sha in protocol['code_sha256'].items():
        assert file_digest(Path(path)) == sha, f'code changed during run: {path}'
    for path, sha in protocol['paper_sha256'].items():
        assert file_digest(Path(path)) == sha, f'paper changed: {path}'
    for name, sha in protocol['data_sha256'].items():
        assert file_digest(Path(protocol['dataset']) / name) == sha, f'data changed: {name}'
    assert file_digest(Path('runs/dbmags-ablation/full_report_llm_xhigh.json')) == protocol['historical_report_sha256']
    rows = []
    for original in prepared['rows']:
        row = dict(original)
        row['local_matched_schedule'] = row['local_only'] if row['scheduled'] else row['baseline']
        for arm in ARMS:
            record = results.get(f"{row['case_id']}:{arm}")
            row[arm] = record['predicted_labels'] if record else row['baseline']
        rows.append(row)
    subset = [r for r in rows if r['scheduled']]
    methods = ['baseline', 'local_matched_schedule', *ARMS]
    labels = prepared['labels']
    views = {
        'same_72_review_cases': {m: metric(subset, m, labels) for m in methods},
        'same_660_cases_same_72_change_opportunities': {m: metric(rows, m, labels) for m in methods},
        'local_rule_on_all_660': metric(rows, 'local_only', labels),
    }
    comparisons = {}
    rng = np.random.default_rng(20260929)
    for left, right in [(ARMS[1], ARMS[0]), (ARMS[1], 'local_matched_schedule'),
                        (ARMS[0], 'local_matched_schedule'),
                        (ARMS[0], 'baseline'), (ARMS[1], 'baseline'),
                        ('local_matched_schedule', 'baseline')]:
        outcome = _revision_outcomes([r['expected_labels'] for r in subset], [r[right] for r in subset], [r[left] for r in subset])
        decisive = outcome['corrected'] + outcome['harmed']
        p = min(1., 2*_binomial_greater_p_value(max(outcome['corrected'], outcome['harmed']), decisive)) if decisive else 1.
        # The six acquisition-replicate folds are the resampling units, not 72 IID samples.
        fold_deltas = []
        for f in prepared['folds']:
            group = [r for r in subset if r['fold'] == f['fold']]
            fold_deltas.append(metric(group,left,labels)['exact']-metric(group,right,labels)['exact'])
        boot = np.mean(rng.choice(fold_deltas,size=(20000,len(fold_deltas)),replace=True),axis=1)
        comparisons[f'{left}_vs_{right}'] = {**outcome, 'exact_gain_pp': float(np.mean(fold_deltas)*100),
            'six_fold_block_bootstrap_95ci_pp': (np.quantile(boot,[.025,.975])*100).tolist(),
            'exploratory_casewise_exact_mcnemar_p': p, 'fold_gain_pp': [x*100 for x in fold_deltas]}
    by_arm = {}
    for arm in ARMS:
        selected = [r for r in decisions if r['arm'] == arm]
        by_arm[arm] = {'requests':len(selected), 'statuses':dict(Counter(r['status'] for r in selected)),
                      'mean_elapsed_seconds':float(np.mean([r['elapsed_seconds'] for r in selected])),
                      'usage':{k:sum(int(r.get('usage',{}).get(k,0) or 0) for r in selected)
                               for k in ['input_tokens','cached_input_tokens','output_tokens','reasoning_output_tokens']}}
    valid_status = {'accepted_selection', 'accepted_abstain'}
    both_valid = [r for r in subset if all(results[f"{r['case_id']}:{a}"]['status'] in valid_status for a in ARMS)]
    diagnostics = {
        'n':len(both_valid),
        'note':'secondary transport-valid paired subset only; primary results retain every scheduled case and fallback',
        'metrics':{a:metric(both_valid,a,labels) for a in methods} if both_valid else {},
    }
    # Independently count sets, without the historical metric helpers.
    independent = {}
    for scope, selected, fields in [
        ('same_72_review_cases', subset, methods),
        ('same_660_cases_same_72_change_opportunities', rows, methods),
        ('local_rule_on_all_660', rows, ['local_only']),
    ]:
        independent[scope] = {}
        for field in fields:
            pairs = [(set(r['expected_labels']), set(r[field])) for r in selected]
            exact = sum(t == p for t, p in pairs)
            tp = sum(len(t & p) for t, p in pairs)
            fp = sum(len(p - t) for t, p in pairs)
            fn = sum(len(t - p) for t, p in pairs)
            counted = {'n': len(pairs), 'exact_correct': exact, 'tp': tp, 'fp': fp, 'fn': fn,
                       'exact': exact / len(pairs), 'component_f1': 2 * tp / (2 * tp + fp + fn)}
            referenced = views[scope] if field == 'local_only' else views[scope][field]
            assert abs(counted['exact'] - referenced['exact']) < 1e-12
            assert abs(counted['component_f1'] - referenced['component_f1']) < 1e-12
            independent[scope][field] = counted
    pool_diagnostics = {}
    for scope, selected in [('all_660', rows), ('same_72_review_cases', subset)]:
        pool_diagnostics[scope] = {
            'n': len(selected),
            'full_pool_gold_retained': sum(any(set(c) == set(r['expected_labels']) for c in r['candidate_pool']) for r in selected),
            'filtered_pool_gold_retained': sum(any(set(c) == set(r['expected_labels']) for c in r['retained_pool']) for r in selected),
            'mean_full_pool_size': float(np.mean([len(r['candidate_pool']) for r in selected])),
            'mean_filtered_pool_size': float(np.mean([len(r['retained_pool']) for r in selected])),
            'filtered_singleton_cases': sum(len(r['retained_pool']) == 1 for r in selected),
        }
    def contains_gold(row, field):
        return any(set(c) == set(row['expected_labels']) for c in row[field])
    candidate_groups = {
        'gold_in_filtered_pool': [r for r in subset if contains_gold(r, 'retained_pool')],
        'gold_removed_by_filter': [r for r in subset if contains_gold(r, 'candidate_pool') and not contains_gold(r, 'retained_pool')],
        'gold_absent_from_full_pool': [r for r in subset if not contains_gold(r, 'candidate_pool')],
    }
    filter_audit = {name: {'n': len(group), 'correct_by_method': {
        field: sum(set(r[field]) == set(r['expected_labels']) for r in group) for field in methods}}
        for name, group in candidate_groups.items()}
    outside = [r for r in subset if not any(set(r[ARMS[0]]) == set(c) for c in r['retained_pool'])]
    filter_audit['full_llm_selected_outside_filtered_pool'] = {
        'n': len(outside), 'correct': sum(set(r[ARMS[0]]) == set(r['expected_labels']) for r in outside)}
    action_audit = {}
    for arm in ARMS:
        improved = [r for r in subset if set(r[arm]) == set(r['expected_labels'])
                    and set(r['local_matched_schedule']) != set(r['expected_labels'])]
        harmed = [r for r in subset if set(r[arm]) != set(r['expected_labels'])
                  and set(r['local_matched_schedule']) == set(r['expected_labels'])]
        action_audit[arm] = {name: dict(Counter(results[f"{r['case_id']}:{arm}"]['status'] for r in selected))
                            for name, selected in [('corrected_vs_local', improved), ('harmed_vs_local', harmed)]}
    paired_by_fold = {f['fold']: {m: metric([r for r in subset if r['fold'] == f['fold']], m, labels)
                                for m in methods} for f in prepared['folds']}
    ledger_fields = ['case_id', 'fold', 'expected_labels', *methods, 'gold_in_full_pool',
                     'gold_in_filtered_pool', 'filtered_pool_size', *(a+'_status' for a in ARMS)]
    with (output/'paired_case_audit.csv').open('w', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=ledger_fields)
        writer.writeheader()
        for r in subset:
            row = {key: r[key] for key in ['case_id', 'fold']}
            row.update({field: '+'.join(sorted(r[field])) for field in ['expected_labels', *methods]})
            row.update(gold_in_full_pool=contains_gold(r, 'candidate_pool'),
                       gold_in_filtered_pool=contains_gold(r, 'retained_pool'),
                       filtered_pool_size=len(r['retained_pool']))
            row.update({a+'_status': results[f"{r['case_id']}:{a}"]['status'] for a in ARMS})
            writer.writerow(row)
    write_json(output/'independent_final_count_check.json', independent)
    report = {'views':views,'comparisons':comparisons,'api':by_arm,'paired_valid_diagnostic':diagnostics,
              'independent_set_counts': independent, 'pool_diagnostics': pool_diagnostics,
              'filter_audit': filter_audit, 'paired_by_fold': paired_by_fold,
              'llm_action_audit_vs_local': action_audit,
              'protocol_sha256':digest(protocol),'manuscript_and_legacy_report_unchanged':True,
              'limitations':['72 upstream-uncertain cases (12/fold), not an all-660 LLM evaluation',
                             'CLI model wrapper/transport and pooled prompt differ from historical raw API; compare new arms to each other',
                             'local-only deterministic readout is an explicit adapter to the historical candidate filter',
                             'six repeated-scenario acquisition folds; no unseen-scenario or unseen-combination claim',
                             'one model realization per scheduled case and arm; exploratory uncertainty with only six folds']}
    write_json(output/'controlled_analysis.json',report)
    return report


if __name__ == '__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,default=Path('runs/ecsa-isolation-20260929'))
    args=parser.parse_args();print(json.dumps(analyze(args.output),ensure_ascii=False,indent=2))
