"""Frozen follow-up experiment: train-only calibration and three fixed cohorts."""
from __future__ import annotations

import argparse
from collections import Counter
from concurrent.futures import ThreadPoolExecutor, as_completed
import hashlib
import json
import pickle
from pathlib import Path
import time

import numpy as np

import hyperdbdiag_ablation as original
from structured_evidence_judge import StructuredEvidenceJudge
from conservative_evidence_judge import describe_pool, calibrate, retain_pool
from ecsa_isolation_experiment import (build_packets, digest, file_digest, write_json,
    execute_job, configured_codex_client, INSTRUCTIONS, SCHEMA)

OUTPUT = Path('runs/ecsa-conservative-20260929')
PRIOR = Path('runs/ecsa-isolation-20260929')
ARMS = ('llm_full_pool', 'original_filtered_pool', 'conservative_filtered_pool')
COHORTS = ('historical_72', 'previous_uncertainty_72', 'fresh_random_72')
SEED = 20260802
COHORT_SEED = 20260929


def fit_cached(output, dataset, ids, x, labels, groups, semantic):
    key = digest({'ids':list(ids), 'x':hashlib.sha256(x.tobytes()).hexdigest(),
                  'labels':list(labels), 'groups':[int(g) for g in groups],
                  'semantic':repr(semantic), 'seed':SEED})
    path = output/'fit_cache'/f'{key}.pickle'
    if path.exists():
        # Only self-created models under this experiment's frozen protocol.
        with path.open('rb') as stream:
            return pickle.load(stream)
    model = original._new_h_model(dataset, SEED).fit(x, labels, dataset.labels, groups, semantic)
    judge = StructuredEvidenceJudge().fit(x,labels,groups,dataset.labels,dataset.feature_names)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('wb') as stream:
        pickle.dump((model,judge),stream,protocol=pickle.HIGHEST_PROTOCOL)
    return model, judge


def prepare(output):
    if (output/'prepared.json').exists():
        raise ValueError('frozen preparation exists; do not overwrite')
    protected = [Path('main.tex'),Path('HyperDBDiag2.docx'),
                 Path('runs/dbmags-ablation/full_report_llm_xhigh.json')]
    protected += sorted(p for p in Path('figures').glob('*') if p.is_file())
    sources = [Path(__file__),Path('src/conservative_evidence_judge.py'),
               Path('src/structured_evidence_judge.py'),Path('src/hyperdbdiag_ablation.py'),
               Path('src/hypergraph_core.py'),Path('src/ecsa_isolation_experiment.py'),
               Path('src/hyperdbdiag_pipeline.py')]
    protocol = {
        'name':'ecsa_conservative_train_calibrated_v1', 'seed':SEED, 'cohort_seed':COHORT_SEED,
        'model':'gpt-5.5','reasoning_effort':'xhigh','transport':'official CLI ChatGPT login',
        'workers':4,'repeated_model_draws_per_unique_packet':1,
        'cohorts':{
            COHORTS[0]:'reconstruct the actual historical local-challenger review schedule, 12/fold',
            COHORTS[1]:'exactly the previous frozen uncertainty schedule, 12/fold',
            COHORTS[2]:'12/fold by SHA256(seed, fold, case_id), excluding both earlier schedules; fixed before new LLM outcomes'},
        'candidate_filter':'keep full pool without calibrated local advantage; otherwise retain baseline, local choice, and every candidate within the OOF-calibrated evidence gap',
        'profile_threshold_grid':[.05,.10,.20,.40,.80,None],
        'profile_selection':'maximum training OOF exact, ties fewer overrides then higher threshold',
        'pool_retention_target':.99,'minimum_inner_group_retention':.97,
        'calibration':'full five-group inner cross fitting inside each outer training fold, including upstream fitting; no outer labels',
        'primary_fallback':'common upstream top1 for each arm on abstention/failure, to isolate pool restriction',
        'secondary_integrated_flow':'new local prediction on all cases; accepted conservative LLM selection replaces it on each fixed 72-case schedule; otherwise keep local prediction',
        'historical_row_policy':'old original code/report are preserved; new experiments do not silently replace historical numbers',
        'memoization':'exact canonical packet hash plus identical frozen prompt/schema/model permits shared inference; report actual new calls separately; no outcome-based reruns',
        'analysis_scope':'development experiment on the same v11 dataset; fresh_random means new scheduled model calls, not a new independent dataset',
        'instructions_sha256':digest(INSTRUCTIONS),'schema_sha256':digest(SCHEMA),
        'source_sha256':{str(p):file_digest(p) for p in sources},
        'protected_sha256':{str(p):file_digest(p) for p in protected},
        'data_sha256':{str(p):file_digest(p) for p in original.DEFAULT_DBMAGS_ROOT.glob('*.json')},
        'prior_artifacts_sha256':{str(PRIOR/name):file_digest(PRIOR/name) for name in
                                 ['prepared.json','protocol.json','llm_decisions.jsonl']},
    }
    old_protocol = output/'protocol.json'
    if old_protocol.exists() and json.loads(old_protocol.read_text()) != protocol:
        raise ValueError('preparation protocol changed; use another output directory')
    write_json(old_protocol,protocol)
    cards,_ = original._load_root_mechanism_cards()
    dataset = original._load_dbmags(original.DEFAULT_DBMAGS_ROOT,cards)
    cards = dataset.mechanism_cards
    previous = json.loads((PRIOR/'prepared.json').read_text())
    prior_by_id = {r['case_id']:r for r in previous['rows']}
    historical = next(iter(json.loads(Path('runs/dbmags-ablation/full_report_llm_xhigh.json').read_text())['datasets'].values()))
    history_base = {r['case_id']:set(r['predicted_labels']) for r in historical['methods']['hypergraph']['results']}
    historical_changed = {r['case_id'] for r in historical['methods']['hyperdbdiag']['results']
                          if set(r['predicted_labels']) != history_base[r['case_id']]}
    rows,jobs,folds=[],[],[]
    for split in dataset.splits:
        print(f'Preparing {split.split_id}',flush=True)
        split.validate(dataset.feature_count,dataset.labels)
        group_array=np.asarray(split.oof_groups)
        inner_rows=[]
        for group in sorted(set(split.oof_groups)):
            held=group_array==group; fit=~held
            train_ids=[i for i,k in zip(split.train_ids,fit) if k]
            held_ids=[i for i,k in zip(split.train_ids,held) if k]
            train_labels=[r for r,k in zip(split.train_labels,fit) if k]
            train_semantic=[r for r,k in zip(split.train_semantic,fit) if k]
            held_semantic=[r for r,k in zip(split.train_semantic,held) if k]
            held_labels=[r for r,k in zip(split.train_labels,held) if k]
            assert not set(train_ids)&set(held_ids)
            assert not set(split.eval_ids)&(set(train_ids)|set(held_ids))
            started=time.monotonic()
            model,judge=fit_cached(output,dataset,train_ids,split.train_x[fit],train_labels,group_array[fit],train_semantic)
            pools=model.predict_candidate_pool_indices(split.train_x[held],held_semantic)
            candidate_map={frozenset(dataset.labels[j] for j in c):i for i,c in enumerate(model.candidates)}
            for case,query,obs,pool,truth in zip(held_ids,split.train_x[held],held_semantic,pools,held_labels):
                row=describe_pool(judge,model.candidates,pool,query,obs,cards)
                row.update(case_id=case,group=str(group),truth_candidate=candidate_map.get(frozenset(truth)))
                inner_rows.append(row)
            print(f'  inner group {group}: {len(held_ids)} rows, {time.monotonic()-started:.1f}s',flush=True)
        assert {r['case_id'] for r in inner_rows}==set(split.train_ids)
        selected=calibrate(inner_rows)
        write_json(output/'calibration'/f'{split.split_id.replace(":","_")}.json',
                   {'selected':selected,'training_oof_rows':inner_rows,'outer_test_ids_excluded':list(split.eval_ids)})
        threshold=float('inf') if selected['profile_threshold'] is None else selected['profile_threshold']
        gap=float('inf') if selected['evidence_gap'] is None else selected['evidence_gap']
        model,judge=fit_cached(output,dataset,split.train_ids,split.train_x,split.train_labels,split.oof_groups,split.train_semantic)
        probs=model.predict_proba(split.eval_x,split.eval_semantic)
        pools=model.predict_candidate_pool_indices(split.eval_x,split.eval_semantic)
        ids=tuple(f'candidate-{i:03d}' for i in range(len(model.candidates)))
        handoff=original._structured_handoff(model,judge,split.eval_x,ids,semantic_observations=split.eval_semantic,mechanism_cards=cards)
        handoff=original._retain_semantic_challengers(dataset,model,handoff,split.eval_semantic,
                    split.train_labels,split.oof_groups,split.train_semantic)
        scheduled=original._limit_review_handoff(handoff,12,probs)
        hist={case for case,alt in zip(split.eval_ids,scheduled.alternative_indices) if alt is not None}
        prev={case for case in split.eval_ids if prior_by_id[case]['scheduled']}
        eligible=[case for case in split.eval_ids if case not in hist|prev]
        fresh=set(sorted(eligible,key=lambda case:digest([COHORT_SEED,split.split_id,case]))[:12])
        assert len(hist)==len(prev)==len(fresh)==12
        memberships={COHORTS[0]:hist,COHORTS[1]:prev,COHORTS[2]:fresh}
        all_cards=[tuple(judge._card(ids[int(i)],model.candidates[int(i)],query,obs,cards) for i in pool)
                   for query,obs,pool in zip(split.eval_x,split.eval_semantic,pools)]
        evidence=original._llm_evidence(split.eval_x,split.train_x,split.train_labels,split.oof_groups,
                    dataset.labels,dataset.feature_names,cards,all_cards,split.eval_semantic,split.train_semantic,
                    dataset.require_discriminating_semantic_for_llm)
        for n,(case,query,obs,pool,bundle) in enumerate(zip(split.eval_ids,split.eval_x,split.eval_semantic,pools,evidence)):
            description=describe_pool(judge,model.candidates,pool,query,obs,cards)
            decision=retain_pool(description,threshold,gap)
            labels_for=lambda i:[dataset.labels[j] for j in model.candidates[int(i)]]
            base=labels_for(pool[0]); local=labels_for(decision.local_candidate)
            assert set(base)==history_base[case]
            old_pool=[int(pool[0])]+([] if description['challenger'] is None else [description['challenger']])
            # Verify exact identity with the previous frozen supplementary inputs.
            assert [labels_for(i) for i in old_pool]==prior_by_id[case]['retained_pool']
            cohorts=[name for name,selected_ids in memberships.items() if case in selected_ids]
            row={'case_id':case,'fold':split.split_id,'cohorts':cohorts,
                 'expected_labels':list(split.eval_labels[n]),'baseline':base,
                 'original_local':prior_by_id[case]['local_only'],'calibrated_local':local,
                 'full_pool':[labels_for(i) for i in pool],
                 'original_pool':[labels_for(i) for i in old_pool],
                 'conservative_pool':[labels_for(i) for i in decision.retained_candidates],
                 'local_status':decision.status}
            rows.append(row)
            if not cohorts:
                continue
            new_packets=build_packets(bundle,list(map(int,pool)),list(decision.retained_candidates),model.candidates,dataset.labels)
            old_packets=build_packets(bundle,list(map(int,pool)),old_pool,model.candidates,dataset.labels)
            packets={ARMS[0]:new_packets['llm_full_pool'],ARMS[1]:old_packets['ecsa_filtered_pool'],
                     ARMS[2]:new_packets['ecsa_filtered_pool']}
            for arm,packet in packets.items():
                jobs.append({'job_id':f'{case}:{arm}','case_id':case,'fold':split.split_id,'arm':arm,
                             'fallback':base,'packet':packet,'packet_sha256':digest(packet)})
        folds.append({'fold':split.split_id,'calibration':selected,
                      'cohort_case_ids':{k:sorted(v) for k,v in memberships.items()}})
        print(json.dumps({'completed_outer_folds':len(folds),'profile_threshold':selected['profile_threshold'],
                          'evidence_gap':selected['evidence_gap']}),flush=True)
    reconstructed={r['case_id'] for r in rows if COHORTS[0] in r['cohorts']}
    assert historical_changed <= reconstructed, 'historical changed cases not in reproduced schedule'
    prepared={'protocol_sha256':digest(protocol),'labels':list(dataset.labels),'rows':rows,'jobs':jobs,'folds':folds,
              'history_changed_cases_covered':len(historical_changed),'unique_scheduled_cases':sum(bool(r['cohorts']) for r in rows)}
    write_json(output/'prepared.json',prepared)
    print(json.dumps({'status':'prepared','cases':len(rows),'scheduled':prepared['unique_scheduled_cases'],
                      'logical_arm_decisions':len(jobs)}),flush=True)


def verify(output):
    p=json.loads((output/'protocol.json').read_text()); d=json.loads((output/'prepared.json').read_text())
    assert digest(p)==d['protocol_sha256']
    for key in ['source_sha256','protected_sha256','data_sha256','prior_artifacts_sha256']:
        for name,h in p[key].items():
            assert file_digest(Path(name))==h, f'changed frozen artifact: {name}'
    assert digest(INSTRUCTIONS)==p['instructions_sha256'] and digest(SCHEMA)==p['schema_sha256']
    return p,d


def run(output):
    protocol,prepared=verify(output)
    prior_protocol=json.loads((PRIOR/'protocol.json').read_text())
    for key in ['model','reasoning_effort','instructions_sha256','schema_sha256']:
        assert prior_protocol[key]==protocol[key]
    source_by_packet={}
    for line in (PRIOR/'llm_decisions.jsonl').read_text().splitlines():
        r=json.loads(line)
        if r['status'] in ['accepted_selection','accepted_abstain']:
            # Full and original filtered requests may coincide; earliest valid draw is fixed.
            source_by_packet.setdefault(r['packet_sha256'],{**r,'reuse_source':'previous_frozen_run'})
    checkpoint=output/'new_model_calls.jsonl'
    if checkpoint.exists():
        for line in checkpoint.read_text().splitlines():
            r=json.loads(line)
            assert r['packet_sha256'] not in source_by_packet
            source_by_packet[r['packet_sha256']]=r
    by_packet={}
    for job in prepared['jobs']:
        assert digest(job['packet'])==job['packet_sha256']
        by_packet.setdefault(job['packet_sha256'],job)
    pending=[j for h,j in by_packet.items() if h not in source_by_packet]
    client,config=configured_codex_client(output)
    config['workers']=protocol['workers']
    config['cache_rule']=protocol['memoization']
    config_path=output/'llm_configuration.json'
    if config_path.exists(): assert json.loads(config_path.read_text())==config
    write_json(config_path,config)
    reused=sum(j['packet_sha256'] in source_by_packet for j in prepared['jobs'])
    print(json.dumps({'logical_decisions':len(prepared['jobs']),'unique_packets':len(by_packet),
                      'already_covered_logical_decisions':reused,'new_unique_calls':len(pending)}),flush=True)
    total_new_before=sum(r.get('reuse_source')!='previous_frozen_run' for r in source_by_packet.values())
    with checkpoint.open('a') as stream,ThreadPoolExecutor(max_workers=protocol['workers']) as pool:
        futures={pool.submit(execute_job,job,client):job for job in pending}
        completed=0
        for future in as_completed(futures):
            result=future.result();result['reuse_source']='current_frozen_run'
            stream.write(json.dumps(result,ensure_ascii=False)+'\n');stream.flush()
            source_by_packet[result['packet_sha256']]=result;completed+=1
            progress={'completed_new_calls':total_new_before+completed,'planned_new_calls':total_new_before+len(pending),
                      'statuses':dict(Counter(r['status'] for r in source_by_packet.values() if r.get('reuse_source')!='previous_frozen_run'))}
            write_json(output/'progress.json',progress)
            print(json.dumps(progress),flush=True)
    results=[]
    for job in prepared['jobs']:
        source=source_by_packet[job['packet_sha256']]
        row={k:job[k] for k in ['job_id','case_id','fold','arm','packet_sha256']}
        row.update({k:source[k] for k in ['status','usage','elapsed_seconds','reuse_source']})
        if 'decision' in source: row['decision']=source['decision']
        if source['status']=='accepted_selection':
            row['predicted_labels']=next(r['root_labels'] for r in job['packet']['candidate_records']
                                        if r['candidate_id']==source['decision']['candidate_id'])
        else:
            row['predicted_labels']=job['fallback']
        results.append(row)
    verify(output)
    write_json(output/'decisions.json',results)
    write_json(output/'run_completion.json',{'logical_decisions':len(results),'unique_packets':len(by_packet),
               'actual_new_model_calls':sum(r.get('reuse_source')!='previous_frozen_run' for r in source_by_packet.values()),
               'new_statuses':dict(Counter(r['status'] for r in source_by_packet.values() if r.get('reuse_source')!='previous_frozen_run')),
               'protected_artifacts_unchanged':True})
    print('all scheduled decisions complete',flush=True)


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('stage',choices=['prepare','run'])
    parser.add_argument('--output',type=Path,default=OUTPUT)
    args=parser.parse_args()
    prepare(args.output) if args.stage=='prepare' else run(args.output)
