"""Expand the frozen ECSA comparison to all 660 cases and a fixed repeat audit.

Reuses the existing fold-specific models, training-only calibration, prompts,
and valid model decisions. No model/policy selection uses expansion outcomes.
"""
from __future__ import annotations

import argparse
from collections import Counter, deque
from concurrent.futures import FIRST_COMPLETED, ThreadPoolExecutor, wait
import hashlib
import json
from pathlib import Path
import time

import hyperdbdiag_ablation as original
from ecsa_conservative_experiment import ARMS, OUTPUT as PREVIOUS, PRIOR, SEED, fit_cached, verify as verify_previous
from ecsa_isolation_experiment import (INSTRUCTIONS, SCHEMA, build_packets, configured_codex_client,
    digest, execute_job, file_digest, validate_response, write_json)

OUTPUT = Path('runs/ecsa-full660-20260929')
REPEAT_SEED = 20260930
REPEAT_PER_FOLD = 10
WORKERS = 8
VALID = {'accepted_selection', 'accepted_abstain'}


def request_key(job):
    return f"{job['draw']}:{job['packet_sha256']}"


def deterministic_singleton(job):
    """Resolve only when every possible valid choice and fallback is identical."""
    records = job['packet']['candidate_records']
    if len(records) != 1 or set(records[0]['root_labels']) != set(job['fallback']):
        return None
    return {'status':'deterministic_singleton', 'predicted_labels':list(job['fallback']),
            'usage':{}, 'elapsed_seconds':0.0, 'source':'analytical_singleton',
            'model_called':False}


def load_previous_decisions():
    result = {}
    for path in [PRIOR/'llm_decisions.jsonl', PREVIOUS/'new_model_calls.jsonl']:
        for line in path.read_text().splitlines():
            row = json.loads(line)
            if row['status'] in VALID:
                result.setdefault('primary:'+row['packet_sha256'],
                    {**row, 'source':str(path), 'model_called':True})
    return result


def prepare(output):
    if (output/'prepared.json').exists():
        raise ValueError('already prepared; preserve frozen inputs')
    old_protocol, previous = verify_previous(PREVIOUS)
    sources = [Path(__file__), Path('src/conservative_evidence_judge.py'),
               Path('src/ecsa_conservative_experiment.py'), Path('src/ecsa_isolation_experiment.py'),
               Path('src/hyperdbdiag_ablation.py'),Path('src/hyperdbdiag_pipeline.py'),
               Path('src/structured_evidence_judge.py'),Path('src/hypergraph_core.py')]
    protocol = {
        'name':'ecsa_all660_fixed_policy_v1','seed':SEED,'workers':WORKERS,
        'model':'gpt-5.5','reasoning_effort':'xhigh','transport':'official Codex CLI / ChatGPT login',
        'scope':'all 660 cases, same six 550-train/110-test outer folds; no test call budget or selected-case gate',
        'policy':'unchanged conservative local calibration and original comparator from previous frozen experiment',
        'primary_interpretation':'compare all methods on all 660; complete flow uses calibrated local fallback; report common upstream fallback separately to isolate pool effect',
        'arms':list(ARMS),
        'repeat_audit':{'cases_per_fold':REPEAT_PER_FOLD,'seed':REPEAT_SEED,
            'selection':'fixed hash order among cases whose conservative candidate pool differs from full pool; no outcomes/labels used',
            'arms':[ARMS[0],ARMS[2]],'draws':'one additional fresh draw, never used to select a preferred answer'},
        'reuse':'same primary packet, prompt, schema, and model settings reuse earliest valid stored draw; repeat namespace always fresh',
        'singleton':'no new inference when one candidate equals fallback; all possible valid decisions give the same prediction; explicitly mark analytical resolution',
        'failure_policy':'retain every planned case; abstention/failure fallback; stop an apparent transport outage after eight consecutive transport failures',
        'latency_note':'workers increased from four to eight for this expansion; no cross-run latency claim',
        'development_note':'expanded inference coverage on the same v11 dataset, not newly collected independent data; no policy changes during this run',
        'instructions_sha256':digest(INSTRUCTIONS),'schema_sha256':digest(SCHEMA),
        'source_sha256':{str(p):file_digest(p) for p in sources},
        'protected_sha256':old_protocol['protected_sha256'],
        'data_sha256':old_protocol['data_sha256'],
        'prior_sha256':{str(p):file_digest(p) for p in [PREVIOUS/'protocol.json',PREVIOUS/'prepared.json',
                           PREVIOUS/'new_model_calls.jsonl',PREVIOUS/'decisions.json',
                           PRIOR/'protocol.json',PRIOR/'prepared.json',PRIOR/'llm_decisions.jsonl']},
    }
    if (output/'protocol.json').exists():
        assert json.loads((output/'protocol.json').read_text()) == protocol
    write_json(output/'protocol.json',protocol)
    catalog,_ = original._load_root_mechanism_cards()
    dataset = original._load_dbmags(original.DEFAULT_DBMAGS_ROOT,catalog)
    previous_rows = {r['case_id']:r for r in previous['rows']}
    previous_jobs = {r['job_id']:r for r in previous['jobs']}
    rows,jobs,folds = [],[],[]
    for split in dataset.splits:
        print(f'Preparing all cases in {split.split_id}',flush=True)
        split.validate(dataset.feature_count,dataset.labels)
        # Verify the pre-existing cache is present before using the old cache helper.
        key = digest({'ids':list(split.train_ids), 'x':hashlib.sha256(split.train_x.tobytes()).hexdigest(),
                      'labels':list(split.train_labels), 'groups':[int(g) for g in split.oof_groups],
                      'semantic':repr(split.train_semantic), 'seed':SEED})
        assert (PREVIOUS/'fit_cache'/f'{key}.pickle').exists(), 'missing frozen outer model'
        model,judge = fit_cached(PREVIOUS,dataset,split.train_ids,split.train_x,
                                split.train_labels,split.oof_groups,split.train_semantic)
        pools = model.predict_candidate_pool_indices(split.eval_x,split.eval_semantic)
        ids = tuple(f'candidate-{i:03d}' for i in range(len(model.candidates)))
        lookup = {frozenset(dataset.labels[j] for j in c):i for i,c in enumerate(model.candidates)}
        cards = [tuple(judge._card(ids[int(i)],model.candidates[int(i)],q,obs,dataset.mechanism_cards) for i in pool)
                 for q,obs,pool in zip(split.eval_x,split.eval_semantic,pools)]
        evidence = original._llm_evidence(split.eval_x,split.train_x,split.train_labels,split.oof_groups,
            dataset.labels,dataset.feature_names,dataset.mechanism_cards,cards,split.eval_semantic,
            split.train_semantic,dataset.require_discriminating_semantic_for_llm)
        eligible = [case for case in split.eval_ids if
                    len(previous_rows[case]['conservative_pool']) < len(previous_rows[case]['full_pool'])]
        repeat_ids = set(sorted(eligible,key=lambda c:digest([REPEAT_SEED,split.split_id,c]))[:REPEAT_PER_FOLD])
        assert len(repeat_ids)==REPEAT_PER_FOLD
        for case,pool,bundle,truth in zip(split.eval_ids,pools,evidence,split.eval_labels):
            old = previous_rows[case]
            assert old['expected_labels']==list(truth)
            labels_for=lambda i:[dataset.labels[j] for j in model.candidates[int(i)]]
            assert [labels_for(i) for i in pool]==old['full_pool']
            original_pool=[lookup[frozenset(c)] for c in old['original_pool']]
            conservative_pool=[lookup[frozenset(c)] for c in old['conservative_pool']]
            old_packets=build_packets(bundle,list(map(int,pool)),original_pool,model.candidates,dataset.labels)
            new_packets=build_packets(bundle,list(map(int,pool)),conservative_pool,model.candidates,dataset.labels)
            packets={ARMS[0]:new_packets['llm_full_pool'],ARMS[1]:old_packets['ecsa_filtered_pool'],
                     ARMS[2]:new_packets['ecsa_filtered_pool']}
            row={**old,'previously_reviewed':bool(old['cohorts']),'repeat_selected':case in repeat_ids}
            rows.append(row)
            for arm,packet in packets.items():
                if f'{case}:{arm}' in previous_jobs:
                    assert digest(packet)==previous_jobs[f'{case}:{arm}']['packet_sha256']
                job={'job_id':f'{case}:{arm}:primary','case_id':case,'fold':split.split_id,'arm':arm,
                     'draw':'primary','fallback':old['baseline'],'local_fallback':old['calibrated_local'],
                     'packet':packet,'packet_sha256':digest(packet)}
                jobs.append(job)
                if case in repeat_ids and arm in [ARMS[0],ARMS[2]]:
                    jobs.append({**job,'draw':'repeat','job_id':f'{case}:{arm}:repeat'})
        folds.append({'fold':split.split_id,'train_n':len(split.train_ids),'test_n':len(split.eval_ids),
                      'repeat_case_ids':sorted(repeat_ids)})
    assert len(rows)==660 and len({r['case_id'] for r in rows})==660
    assert len(jobs)==660*3+60*2
    prepared={'protocol_sha256':digest(protocol),'labels':list(dataset.labels),'rows':rows,'jobs':jobs,'folds':folds}
    write_json(output/'prepared.json',prepared)
    prior=load_previous_decisions();unique={}
    singleton_count=0
    for job in jobs:
        if deterministic_singleton(job) is not None:
            singleton_count+=1
        else:
            unique.setdefault(request_key(job),job)
    pending=[key for key in unique if key not in prior]
    plan={'primary_cases':660,'primary_method_decisions':1980,'repeat_cases':60,'repeat_decisions':120,
          'analytical_singletons':singleton_count,'unique_inference_keys':len(unique),
          'reused_inference_keys':len(unique)-len(pending),'new_primary_calls':sum(k.startswith('primary:') for k in pending),
          'new_repeat_calls':sum(k.startswith('repeat:') for k in pending),'total_new_calls':len(pending)}
    write_json(output/'execution_plan.json',plan)
    print(json.dumps(plan),flush=True)


def verify(output):
    p=json.loads((output/'protocol.json').read_text());d=json.loads((output/'prepared.json').read_text())
    assert digest(p)==d['protocol_sha256']
    for family in ['source_sha256','protected_sha256','data_sha256','prior_sha256']:
        for name,h in p[family].items():assert file_digest(Path(name))==h,f'frozen file changed: {name}'
    assert digest(INSTRUCTIONS)==p['instructions_sha256'] and digest(SCHEMA)==p['schema_sha256']
    return p,d


def materialize(job, source):
    row={k:job[k] for k in ['job_id','case_id','fold','arm','draw','packet_sha256']}
    row.update({k:source[k] for k in ['status','usage','elapsed_seconds','source','model_called']})
    if source['status']=='accepted_selection':
        decision=validate_response(source['decision'],job['packet'])
        prediction=next(c['root_labels'] for c in job['packet']['candidate_records'] if c['candidate_id']==decision['candidate_id'])
        row['decision']=decision
    else:
        prediction=job['fallback']
        if source['status']=='accepted_abstain':row['decision']=validate_response(source['decision'],job['packet'])
    row['predicted_labels']=list(prediction)
    row['local_fallback_prediction']=(list(prediction) if source['status']=='accepted_selection' else list(job['local_fallback']))
    return row


def run(output):
    protocol,prepared=verify(output)
    source=load_previous_decisions()
    checkpoint=output/'new_model_calls.jsonl'
    if checkpoint.exists():
        for line in checkpoint.read_text().splitlines():
            row=json.loads(line);key=row['request_key']
            assert key not in source,'duplicate invocation key'
            source[key]=row
    unique={}
    for job in prepared['jobs']:
        assert digest(job['packet'])==job['packet_sha256']
        if deterministic_singleton(job) is None:unique.setdefault(request_key(job),job)
    pending=[job for key,job in unique.items() if key not in source]
    # Mix arms/folds with a frozen hash order, independently of labels/outcomes.
    pending.sort(key=lambda j:digest([20260929,request_key(j)]))
    client,config=configured_codex_client(output)
    config.update(workers=protocol['workers'],same_primary_packet_cache=True,repeat_namespace_fresh=True)
    old_config=json.loads((PREVIOUS/'llm_configuration.json').read_text())
    for key in ['model','reasoning_effort','transport','cli_version','instructions_sha256','schema_sha256']:
        assert config[key]==old_config[key],f'cannot silently reuse changed model context: {key}'
    if (output/'llm_configuration.json').exists():assert json.loads((output/'llm_configuration.json').read_text())==config
    write_json(output/'llm_configuration.json',config)
    already=[r for r in source.values() if r.get('source')=='current_fullcoverage']
    count_before=len(already);plan=count_before+len(pending)
    queue=iter(pending);recent=deque(maxlen=8)
    active={};finished=0;stopping=False
    print(json.dumps({'new_calls_already_saved':count_before,'remaining':len(pending),'workers':protocol['workers']}),flush=True)
    with checkpoint.open('a') as stream,ThreadPoolExecutor(max_workers=protocol['workers']) as executor:
        def submit_one():
            job=next(queue,None)
            if job is None:return False
            active[executor.submit(execute_job,job,client)]=job
            return True
        for _ in range(protocol['workers']):submit_one()
        while active:
            done,_=wait(active,return_when=FIRST_COMPLETED)
            for future in done:
                job=active.pop(future);record=future.result()
                record.update(draw=job['draw'],request_key=request_key(job),source='current_fullcoverage',model_called=True)
                stream.write(json.dumps(record,ensure_ascii=False)+'\n');stream.flush()
                source[record['request_key']]=record;finished+=1;recent.append(record['status'])
                current=[r for r in source.values() if r.get('source')=='current_fullcoverage']
                progress={'completed_new_calls':count_before+finished,'planned_new_calls':plan,
                          'statuses':dict(Counter(r['status'] for r in current)),
                          'completed_by_draw':dict(Counter(r['draw'] for r in current))}
                write_json(output/'progress.json',progress);print(json.dumps(progress),flush=True)
                if len(recent)==8 and all(s=='fallback_transport' for s in recent):stopping=True
                if not stopping:submit_one()
        if stopping:raise RuntimeError('apparent transport outage; completed records saved, remaining requests not submitted')
    results=[]
    for job in prepared['jobs']:
        analytical=deterministic_singleton(job)
        origin=analytical if analytical is not None else source[request_key(job)]
        results.append(materialize(job,origin))
    verify(output)
    write_json(output/'decisions.json',results)
    current=[r for r in source.values() if r.get('source')=='current_fullcoverage']
    write_json(output/'run_completion.json',{'logical_decisions':len(results),'primary_cases':660,'repeat_cases':60,
        'actual_new_model_calls':len(current),'new_statuses':dict(Counter(r['status'] for r in current)),
        'new_calls_by_draw':dict(Counter(r['draw'] for r in current)),
        'analytical_singleton_decisions':sum(r['status']=='deterministic_singleton' for r in results),
        'protected_artifacts_unchanged':True})
    print('full coverage and repeat audit complete',flush=True)


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('stage',choices=['prepare','run'])
    parser.add_argument('--output',type=Path,default=OUTPUT)
    args=parser.parse_args();prepare(args.output) if args.stage=='prepare' else run(args.output)
