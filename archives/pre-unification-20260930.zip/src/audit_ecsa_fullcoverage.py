"""Independent input/output consistency audit of the frozen all-case experiment."""
from collections import Counter
from pathlib import Path
import json
import re

from ecsa_fullcoverage_experiment import (
    OUTPUT, PREVIOUS, ARMS, REPEAT_SEED, REPEAT_PER_FOLD,
    verify, deterministic_singleton, materialize, request_key, load_previous_decisions,
)
from ecsa_isolation_experiment import digest, write_json


def audit(output=OUTPUT):
    _, prepared=verify(output)
    rows={r['case_id']:r for r in prepared['rows']}
    jobs={(j['case_id'],j['arm'],j['draw']):j for j in prepared['jobs']}
    assert len(rows)==660 and len(jobs)==2100
    prior=json.loads((PREVIOUS/'prepared.json').read_text())
    previous={(j['case_id'],j['arm']):j for j in prior['jobs']}
    unchanged_prior=0
    forbidden={'case_id','expected_labels','truth','truth_candidate','fallback',
               'local_fallback','cohorts','fold','calibrated_local','original_local'}

    def no_metadata(value):
        if isinstance(value,dict):
            assert not (set(value)&forbidden)
            for item in value.values(): no_metadata(item)
        elif isinstance(value,list):
            for item in value:no_metadata(item)

    for case,row in rows.items():
        full=jobs[(case,ARMS[0],'primary')]['packet']
        by_candidate={c['candidate_id']:c for c in full['candidate_records']}
        by_card={c['evidence_id']:c for c in full['evidence']['candidate_evidence_cards']}
        assert len(by_candidate)==4
        for arm,field in zip(ARMS,['full_pool','original_pool','conservative_pool']):
            job=jobs[(case,arm,'primary')];packet=job['packet']
            assert digest(packet)==job['packet_sha256']
            no_metadata(packet)
            assert not re.search(r'case-\d{4}',json.dumps(packet))
            assert {frozenset(c['root_labels']) for c in packet['candidate_records']}=={frozenset(c) for c in row[field]}
            for candidate in packet['candidate_records']:
                assert candidate==by_candidate[candidate['candidate_id']]
            for name,items in packet['evidence'].items():
                if name=='candidate_evidence_cards':
                    assert len(items)==len(packet['candidate_records'])
                    for card in items:assert card==by_card[card['evidence_id']]
                else:assert items==full['evidence'][name]
            if (case,arm) in previous:
                assert job['packet_sha256']==previous[(case,arm)]['packet_sha256']
                unchanged_prior+=1
        if row['repeat_selected']:
            assert len(row['conservative_pool'])<4
            for arm in [ARMS[0],ARMS[2]]:
                first=jobs[(case,arm,'primary')];second=jobs[(case,arm,'repeat')]
                assert first['packet']==second['packet']
                assert request_key(first)!=request_key(second)
    assert unchanged_prior==567
    for fold in prepared['folds']:
        held={r['case_id'] for r in rows.values() if r['fold']==fold['fold']}
        assert len(held)==110
        calibration_name=fold['fold'].replace(':','_')+'.json'
        calibration=json.loads((PREVIOUS/'calibration'/calibration_name).read_text())
        training={r['case_id'] for r in calibration['training_oof_rows']}
        assert len(training)==550 and training.isdisjoint(held)
        assert training|held==set(rows)
        assert set(calibration['outer_test_ids_excluded'])==held
        eligible=[case for case in held if len(rows[case]['conservative_pool'])<4]
        selected=set(sorted(eligible,key=lambda c:digest([REPEAT_SEED,fold['fold'],c]))[:REPEAT_PER_FOLD])
        assert selected==set(fold['repeat_case_ids'])
        assert selected=={case for case in held if rows[case]['repeat_selected']}
    result={'cases':660,'primary_logical_packets':1980,'repeat_logical_packets':120,
        'previous_567_packets_exactly_preserved':True,'shared_evidence_and_cards_identical':True,
        'no_case_id_truth_or_local_decisions_in_model_inputs':True,
        'each_fold_has_550_training_cases_disjoint_from_110_test_cases':True,
        'repeat_selection_exactly_matches_frozen_label_independent_hash_rule':True,
        'repeat_inputs_match_primary_but_have_separate_inference_keys':True,
        'protected_artifacts_and_frozen_sources_unchanged':True}
    write_json(output/'independent_input_audit.json',result)

    if (output/'decisions.json').exists():
        calls=[json.loads(line) for line in (output/'new_model_calls.jsonl').read_text().splitlines()]
        sources=load_previous_decisions();new_keys=set()
        for call in calls:
            key=call['request_key']
            assert key not in sources and key not in new_keys
            new_keys.add(key);sources[key]=call
        decisions=json.loads((output/'decisions.json').read_text())
        actual={r['job_id']:r for r in decisions}
        assert len(actual)==len(decisions)==2100
        for job in prepared['jobs']:
            source=deterministic_singleton(job)
            if source is None:source=sources[request_key(job)]
            assert materialize(job,source)==actual[job['job_id']]
        assert len(calls)==718
        assert Counter(r['draw'] for r in calls)=={'primary':598,'repeat':120}
        result['output_audit']={'all_2100_decisions_revalidated':True,'new_calls':len(calls),
            'new_call_statuses':dict(Counter(r['status'] for r in calls)),
            'all_repeat_calls_are_new':sum(r['draw']=='repeat' for r in calls)==120,
            'analytical_singletons':sum(r['status']=='deterministic_singleton' for r in decisions)}
        write_json(output/'independent_output_audit.json',result['output_audit'])
    return result


if __name__=='__main__':print(json.dumps(audit(),ensure_ascii=False,indent=2))
