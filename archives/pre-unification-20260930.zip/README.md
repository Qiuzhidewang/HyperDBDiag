# HyperDBDiag DB-MAGS Artifact

This workspace has one active dataset and one registered outer evaluation:

- `data/dbmags_interaction_v11_frozen/`: 660 collected DB-MAGS cases, 25 metric-time features, seven atomic roots, and integrity-bound anonymous SQL-shape evidence.
- Six-fold leave-one-replicate-index-out evaluation: each fold trains on 550 cases and evaluates 110 cases, while retaining all 22 scenarios in both partitions.

The retired v10 cohort and pilot collections are not active protocols. All root-detection reports below use the audited v11 cohort and the same registered folds.

## Active Code

- `src/hypergraph_core.py`: independent ordinary graph and signed-incidence hypergraph with a training-fold EPDG prior.
- `src/hyperdbdiag_ablation.py`: the only six-row component ablation.
- `src/opdiag_baseline.py`: paper-aligned OpDiag independent KPI classifiers with a training-fold Top-k root-set adapter.
- `src/dbaiops_baseline.py`: training-fold reproduction of DBAIOps correlation-aware anomaly models, ExperienceGraph, graph evolution, and Top-k root output.
- `src/dbmags_experiment.py`: DB-MAGS main comparison with OpDiag, DBAIOps, and HyperDBDiag.
- `src/structure_efficiency_experiment.py`: ordinary binary graph and metric hypergraph structure-size and traversal comparison.
- `src/operator_bound_experiment.py`: the only SQL/operator audit and post-diagnosis evaluation entry point.
- `src/structured_evidence_judge.py`: local evidence contraction.
- `src/hyperdbdiag_pipeline.py` and `src/hyperdbdiag_llm.py`: constrained LLM arbitration and post-diagnosis advice.

The frozen reader verifies every data hash, including `semantic_evidence.json`. No active runner reads an old raw collection directory, source case ID, scenario name, SQL text, raw plan, or evaluation label as a predictor input. Anonymous SQL-shape atoms are not query IDs, execution plans, or operator IDs.

## Ablation

Run in the only supported Python environment:

```bash
PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=src ./rca39/bin/python \
  src/hyperdbdiag_ablation.py --seed 20260802
```

Without an explicit LLM configuration, the four deterministic rows run and both LLM-dependent rows are marked not run. The deterministic report is `runs/dbmags-ablation/full_report.json`; the completed `gpt-5.5`/`xhigh` run is `runs/dbmags-ablation/full_report_llm_xhigh.json`.

| Variant | Exact | Component F1 | SQL H@1 | Operator H@1 |
| --- | ---: | ---: | ---: | ---: |
| Ordinary binary graph | 28.48% | 64.01% | 51.39% | 100.00% |
| Hypergraph without EPDG | 40.61% | 63.08% | 51.39% | 100.00% |
| EPDG-grounded hypergraph | 57.58% | 74.17% | 93.75% | 91.67% |
| EPDG + local judge | 57.58% | 74.17% | 93.75% | 91.67% |
| Hypergraph + LLM arbitration | 57.73% | 74.27% | 93.75% | 91.67% |
| HyperDBDiag | 65.45% | 79.27% | 93.75% | 91.67% |

EPDG changes 193 predictions relative to the same hypergraph without EPDG: 127 corrections, 15 harms, and 51 changes that remain incorrect. Every outer fold has positive net gain; the one-sided exact sign-test value is `1.39e-23`.

The Exact/F1 columns use the 660-case root-detection benchmark. SQL/Operator
Hit@1 uses the separate 296-case, oracle-root post-diagnosis extension. The two
rows without EPDG share the root-unconditioned SQL/operator configuration; the
four EPDG rows share the root-conditioned binder because local and LLM
arbitration change the upstream root set, not ranking after the oracle root is
given. Operator Hit@1 is conditional on the ground-truth SQL plan, so the 100%
unconditioned value must be read together with its 51.39% SQL Hit@1. On the
strictly shared KPI-only root-detection track, Exact is 42.58% for OpDiag,
33.33% for DBAIOps, and 40.61% for the hypergraph without EPDG.

The completed LLM run used `gpt-5.5`, `xhigh`, the OpenAI-compatible Responses endpoint, `store:false`, two workers, and a 12-review per-fold budget. Training-OOF calibration enabled the direct LLM row in one outer fold and the complete HyperDBDiag row in all six folds. The direct path issued 12 test requests and received 12 valid responses; the complete path issued 72 and received 65. Complete arbitration corrected 52 predictions, harmed none, and left transport or validation failures unchanged. Credentials and raw model responses are not written to reports. The fixed 24-case post-diagnosis sample accepted 18 bounded recommendations, rejected five unsafe recommendations, and never changed a diagnosis.

## Structure Efficiency

The comparison represents the same metric groups with ordinary pairwise edges
and hyperedges, then measures their relation counts and traversal time. Timing
covers graph-structure traversal only.

```bash
PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=src ./rca39/bin/python \
  src/structure_efficiency_experiment.py
```

The report is `runs/dbmags-structure-efficiency/full_report.json`.

| Representation | Mean relation items | Reduction | Mean traversal time | Time reduction |
| --- | ---: | ---: | ---: | ---: |
| Ordinary binary graph | 18,826 | / | 10.108 ms | / |
| Metric hypergraph | 3,783 | 79.90% | 2.045 ms | 79.77% |

These measurements cover graph-structure traversal only; the other diagnosis
stages are not included.

## Main Comparison

Use the deterministic EPDG stage when no LLM is configured:

```bash
PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=src ./rca39/bin/python \
  src/dbmags_experiment.py --seed 20260802 \
  --canonical-method epdg_hypergraph \
  --ablation-report runs/dbmags-ablation/full_report.json \
  --output runs/dbmags-main-comparison/full_report.json
```

Running `src/dbmags_experiment.py` without overrides uses the verified complete LLM report and writes `runs/dbmags-main-comparison/full_report_llm_xhigh.json`; it does not issue new LLM requests.

The verified deterministic comparison is `runs/dbmags-main-comparison/full_report.json`: OpDiag root detection, the DBAIOps paper reproduction, the EPDG hypergraph, and paired exact-set comparisons are evaluated on the same six outer folds. The LLM-backed comparison is `runs/dbmags-main-comparison/full_report_llm_xhigh.json`. DBAIOps derives its database-specific anomaly equations and ExperienceGraph from each outer training fold; its free-form report generator is replaced by the benchmark's closed root inventory and a training-derived Top-k output. The registered folds retain all 22 scenario templates in both partitions, so they measure repeated-block diagnosis rather than unseen-scenario generalization.

| Method | Exact | Precision | Recall | Component F1 | SQL H@1 | Operator H@1 |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| OpDiag | 42.58% | 66.02% | 64.77% | 65.39% | 50.87% | 75.00% |
| DBAIOps | 33.33% | 60.94% | 60.42% | 60.68% | / | / |
| HyperDBDiag | 65.45% | 80.15% | 78.41% | 79.27% | 93.75% | 91.67% |

The four root-set columns use all 660 registered DB-MAGS cases. SQL and
Operator Hit@1 use the 296-case operator-bound extension with 576 root chains
and oracle detected-root input. The OpDiag fine-grained cells are from the
paper-structured DB-MAGS reproduction; DBAIOps has no corresponding
hierarchical SQL/operator attribution stage, so its cells are `/`.

All 22 scenario templates occur in the training and evaluation partitions of every registered replicate holdout. The comparison therefore measures diagnosis on independent collection batches, not unseen-scenario transfer. The paired Exact gain of HyperDBDiag is 22.88 percentage points over OpDiag and 32.12 points over DBAIOps; block-bootstrap 95% intervals are `[18.48, 27.27]` and `[27.58, 36.67]` percentage points.

| Method | Single root | Sequential roots | Overlapping roots |
| --- | ---: | ---: | ---: |
| OpDiag | 56.44% | 39.02% | 21.97% |
| DBAIOps | 45.45% | 29.17% | 17.42% |
| HyperDBDiag | 63.26% | 67.80% | 65.15% |

The occurrence-pattern rows reuse the same held-out predictions. `Sequential roots` combines both injection orders without collapsing either source condition; `Overlapping roots` contains cases in which the second mechanism starts halfway through the first mechanism's active period.

## SQL and Operators

The primary operator-bound extension is `data/dbmags_operator_bound_v4/`. It
contains four preregistered target SQL/plan variants per root and 308 scheduled
cases, of which 296 are operator-evaluable: 96 single-root, 120 double-root,
and 80 triple-root cases. It covers all 15 pairs and all 20 triples of the six
roots with direct SQL/plan operators, and each variant contributes 74 evaluable
cases. The other 12 DB-MAGS atomic roots are explicitly marked `unsupported`
because this environment has neither a safe injector nor an independently
targetable plan operator for them. They are excluded rather than assigned
synthetic SQL or operator targets.

Run the completed v4 audit and evaluation in `rca39`:

```bash
PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=src ./rca39/bin/python \
  src/operator_bound_experiment.py \
  --dataset-root data/dbmags_operator_bound_v4 --audit-only

PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=src ./rca39/bin/python \
  src/operator_bound_experiment.py \
  --dataset-root data/dbmags_operator_bound_v4 \
  --output runs/dbmags-operator-bound-v4/full_report.json
```

This is a conditional post-diagnosis experiment: each method is given the
oracle detected root and ranks the same blind SQL candidates, then the
operators of the ground-truth SQL's plan, matching OpDiag's hierarchical
metric. The two folds hold out root-target SQL templates (variants 1/3 versus
2/4), and each fold has 148 training and 148 evaluation cases. Test target SQLs
do not occur in the training fold, but non-target control SQLs are shared.
Consequently, this evaluates target-template transfer within the same schema
and workload pattern, not unseen-pattern, unseen-database, or end-to-end root
detection generalization.

Ground truth is isolated from held-out rankers and is used only to construct
training targets and score test rankings. Operator identity is the composite
`(sql_id, operator_id)`, because a plan-node fingerprint alone may legitimately
repeat across SQLs. `OpDiag-DBMAGS reproduction` follows the paper's plan-tree
encoder, concurrent-query aggregator, KPI classifier, and hierarchical
attribution structure, but is not the unavailable official implementation.
HyperDBDiag's result evaluates the EPDG root-to-SQL/plan/operator binder; the
upstream hypergraph remains the root-set detector evaluated on the separate
660-case benchmark. The extension has 5-second phase windows, so it is not
merged with or fed into the registered 75-second root classifiers.

The completed v4 target-template holdout covers 576 root chains with no
missing target. The report records SQL Hit@1/Hit@2, the SQL ranking-mistake
ratio, average target ranks, and the joint SQL-Top-2/operator-Top-1 metric in
addition to the conditional Operator Hit@1. Operator ranking is computed
inside the ground-truth SQL plan. The fine-grained ablation removes only the
detected-root-conditioned EPDG binding while retaining the same blind
candidates, features, template folds, and random-forest configuration. Its
results are included directly in the single ablation table above.

The earlier fixed-template collection is not part of the active artifact and
is omitted to prevent its scores from being mixed with the v4 target-template
holdout.

## Validation

```bash
PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=src ./rca39/bin/python -m unittest discover -s tests -v
```

The core hypergraph invariants ensure that a held-out query never changes the fitted incidence matrix, EPDG fusion is selected only by grouped inner OOF data, and every held-out root set exists in the training candidate inventory.
