import unittest
from analyze_ecsa_fullcoverage import compare, failure_gain_bounds
from ecsa_fullcoverage_experiment import deterministic_singleton, materialize, request_key
from test_ecsa_isolation_experiment import IsolationTests


class FullCoverageTests(unittest.TestCase):
    def job(self):
        packet=IsolationTests().fixture()['ecsa_filtered_pool']
        return {'job_id':'case:arm:primary','case_id':'case','fold':'fold','arm':'arm','draw':'primary',
                'packet_sha256':'same-packet','packet':packet,'fallback':['a'],'local_fallback':['b']}

    def test_repeat_draw_cannot_reuse_primary_key(self):
        first=self.job();second={**first,'draw':'repeat'}
        self.assertNotEqual(request_key(first),request_key(second))

    def test_singleton_is_resolved_only_when_fallback_matches(self):
        job=self.job();job['packet']={'candidate_records':[{'root_labels':['a']}]}
        self.assertEqual(deterministic_singleton(job)['predicted_labels'],['a'])
        self.assertFalse(deterministic_singleton(job)['model_called'])
        job['fallback']=['b']
        self.assertIsNone(deterministic_singleton(job))

    def test_multiple_candidates_need_a_real_decision(self):
        self.assertIsNone(deterministic_singleton(self.job()))

    def test_cached_abstention_uses_the_current_cases_fallbacks(self):
        source={'status':'accepted_abstain','predicted_labels':['stale'], 'source':'cache','model_called':True,
                'usage':{},'elapsed_seconds':1.,'decision':dict(action='ABSTAIN',candidate_id=None,
                comparison_candidate_id=None,evidence_ids=[],reason_code='insufficient_evidence',
                relation_type='UNRESOLVED',recommendation='NO_CHANGE')}
        output=materialize(self.job(),source)
        self.assertEqual(output['predicted_labels'],['a'])
        self.assertEqual(output['local_fallback_prediction'],['b'])

    def test_cached_selection_is_validated_and_mapped_to_supplied_candidates(self):
        job=self.job()
        source={'status':'accepted_selection','predicted_labels':['stale'],'source':'cache','model_called':True,
                'usage':{},'elapsed_seconds':1.,'decision':IsolationTests().decision(job['packet'])}
        output=materialize(job,source)
        self.assertEqual(output['predicted_labels'],['b'])
        self.assertEqual(output['local_fallback_prediction'],['b'])

    def test_unequal_fold_strata_use_case_weighted_gain(self):
        rows=[{'fold':'small','expected_labels':['a'],'left':['a'],'right':['b']}]
        rows += [{'fold':'large','expected_labels':['a'],'left':['b'],'right':['b']} for _ in range(3)]
        result=compare(rows,'left','right',['a','b'])
        self.assertEqual(result['exact_gain_pp'],25.0)
        self.assertEqual(result['fold_n'],[3,1])
        self.assertEqual(result['fold_net_correct'],[0,1])
        self.assertEqual(result['exploratory_fold_block_95ci_pp'],[0.,100.])

    def test_shared_failed_inference_cannot_create_pool_effect(self):
        row={'expected_labels':['a'],'left':['b'],'right':['b'],
             'left_status':'fallback_transport','right_status':'fallback_transport',
             'left_packet_sha256':'same','right_packet_sha256':'same'}
        result=failure_gain_bounds([row],'left','right')
        self.assertEqual(result['net_correct_range'],[0,0])
        self.assertEqual(result['shared_failed_pairs_with_zero_possible_pool_difference'],1)

    def test_distinct_failed_inferences_leave_comparison_uncertain(self):
        row={'expected_labels':['a'],'left':['b'],'right':['b'],
             'left_status':'fallback_transport','right_status':'fallback_transport',
             'left_packet_sha256':'first','right_packet_sha256':'second'}
        self.assertEqual(failure_gain_bounds([row],'left','right')['net_correct_range'],[-1,1])


if __name__=='__main__':unittest.main()
